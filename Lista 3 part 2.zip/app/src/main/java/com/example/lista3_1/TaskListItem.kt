package com.example.lista3_1

data class TaskListItem(
    val subject: String,
    val listName: String,
    val taskCount: Int,
    val grade: Float
)
