package com.example.lista3_1

data class ExerciseListItem (
    val exerciseTitle: String,
    val exerciseDescription: String,
    val exercisePoints: Float
)