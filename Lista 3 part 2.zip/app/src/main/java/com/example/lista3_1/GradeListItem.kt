package com.example.lista3_1

data class GradeListItem (
    val subject: String,
    val listCount: Int,
    val grade: Float
)